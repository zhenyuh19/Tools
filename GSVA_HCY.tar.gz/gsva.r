#!/usr/bin/env Rscript

args=commandArgs(trailingOnly=TRUE)
#if (length(args)<15) {
#  stop("Must supply inputs\n",call.=FALSE)
#}

library(GSEABase)
library(GSVA)

method=args[1]
kcdf=args[2]
abs.ranking=as.logical(toupper(args[3]))
min.sz=as.numeric(args[4])
max.sz=args[5]
if(max.sz=='None') {
    max.sz = Inf
} else {
    max.sz = as.numeric(max.sz)
}
parallel.sz=as.numeric(args[6])
parallel.type=args[7]
mx.diff=as.logical(toupper(args[8]))
tau=args[9]
ssgsea.norm=as.logical(toupper(args[10]))
verbose=as.logical(toupper(args[11]))
tempdir=args[12]
outdir=args[13]
prefix=args[14]

geneSets = getGmt(file.path(outdir, '.gs.gmt'))
mat = as.matrix(read.csv(file.path(outdir, '.expr.csv'),header=TRUE,row.names=1,check.names=FALSE))

output = NA
if(tau != 'None') {
    if(tau=='NA') { tau=NA}
    else { tau = as.numeric(tau)}
    output = gsva(mat,geneSets,
        method=method,
        kcdf=kcdf,
        abs.ranking=abs.ranking,
        min.sz=min.sz,
        max.sz=max.sz,
        parallel.sz=parallel.sz,
        mx.diff=mx.diff,
        tau=tau,
        ssgsea.norm=ssgsea.norm,
        verbose=verbose
    )
} else {
    output = gsva(mat,geneSets,
        method=method,
        kcdf=kcdf,
        abs.ranking=abs.ranking,
        min.sz=min.sz,
        max.sz=max.sz,
        parallel.sz=parallel.sz,
        mx.diff=mx.diff,
        ssgsea.norm=ssgsea.norm,
        verbose=verbose
    )
}

normalize = function(x){
  			return((x-min(x))/(max(x)-min(x)))
}

gsvaOut = normalize(output)
gsvaOut = rbind(id = colnames(gsvaOut), gsvaOut)
#print(gsvaOut)

ofile <- paste0(outdir, "/.", prefix, "-gsva.normalize.xls")
write.table(gsvaOut, file = ofile, sep = "\t",quote = F, col.names = F)

